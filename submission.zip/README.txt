Bryan DiLaura & Erik Feller
Apr. 2016

This flash drive is part of the submission for the Memory Simulation Project for ECEN 4593.

Contents:
All of the code for the simulator is located under ./src/
All of the raw output files can be found in ./output/
All of the config files can be found in ./configs/
A build directory can be found under ./Debug/

Additionally, a copy of our report (including code and outputs) has been included in pdf
form, as well as an excel document which contains all of our compiled data. 



IF LOST: please email dilauraba@gmail.com

